A Pen created at CodePen.io. You can find this one at http://codepen.io/johndelatorre/pen/uGIno.

 I was building a very simple Mega menu style nav for my client.
It was designed for a fixed-width page but I think it's possible to make it responsive by replacing menu columns with fluid and span#.
